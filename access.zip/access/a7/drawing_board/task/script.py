#!/usr/bin/env python3

class MagicDrawingBoard:
    def __init__(self, x, y):
        pass

# Uncomment the following code to start using your implementation
#db = MagicDrawingBoard(1,1)
#db.pixel((-1,0))
