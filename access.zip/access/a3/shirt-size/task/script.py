#!/usr/bin/env python3

# Determine the right size of a shirt. Change the function
# below to determine the right size of a shirt.
# Your implementation should work with any specific value.

def get_size(circumference):
    # your code here

    # don't forget to return the computed value!
    return

# The following line calls the function and prints the return
# value to the Console. This way you can check what it does.
print(get_size(111))
