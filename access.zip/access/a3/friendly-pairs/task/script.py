
# You need to complete this function.
# The numbers must be valid according to description before determining friendly parity situations.
# Return the string "Invalid" if they are not valid.
def is_friendly_pair(num1, num2):
    return

#This line prints your method's return so that you can check your output.
print(is_friendly_pair(6, 28))
