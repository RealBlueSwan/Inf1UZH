#!/usr/bin/env python3

def is_valid(password):
    # Implement this function

    # Make sure you return the correct result at the end!
    return

# The following line calls the function and prints the return
# value to the Console. This way you can check what it does.
print(is_valid("abAB12+-"))

