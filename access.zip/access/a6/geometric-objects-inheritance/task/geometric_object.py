from abc import ABC, abstractmethod


class GeometricObject:

    def __init__(self, color, filled):
        pass

    def area(self):
        pass

    def volume(self):
        pass
