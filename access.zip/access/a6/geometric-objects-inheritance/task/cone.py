from task.geometric_object import GeometricObject


class Cone(GeometricObject):
    def __init__(self, color, filled, radius, vertical_height, slant_height):
        pass

    def area(self):
        pass

    def volume(self):
        pass
