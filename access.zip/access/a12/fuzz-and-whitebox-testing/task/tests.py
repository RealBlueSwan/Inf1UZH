#!/usr/bin/env python3
from unittest import TestCase
from task.script import calculate_factorial

class MyTests(TestCase):

    # write here your tests for calculate_factorial
    pass
