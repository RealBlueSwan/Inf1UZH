#!/usr/bin/env python3

def calculate(a, b, c, d):
    return a - ((b*b) / (c - d * (a + b)))

