#!/usr/bin/env python3

def list_unique(elements):
    # return a list containing all unique elements
    return

