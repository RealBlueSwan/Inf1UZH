#!/usr/bin/env python3

# generate the greeting sentence
def generate_greeting(name = "Hans", age = 37):
    greeting = f"Hello {name}, you are {age} years old!"
    return greeting

