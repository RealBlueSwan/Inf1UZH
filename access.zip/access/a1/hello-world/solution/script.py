# This is "source code". It's plain text and you can edit with any text editor
# However, don't attempt to use a rich-text editor such as Microsoft Word!
# Comments, such as these lines, are ignored in Python if they start with an octothorpe (#)

# On this next line, we're using Python's 'print' function to print a line of text:
print("Hello, World!")

# A function often receives "arguments", which are the things contained within the (parantheses)
# In this case, the print function receives exactly one argument, which is a so-called "String".
# Strings are pieces of text and in Python, they are surrounded by quotation marks ("")

