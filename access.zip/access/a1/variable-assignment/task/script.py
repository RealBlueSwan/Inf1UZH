#!/usr/bin/env python3

# This is the arithmetic expression you should change
x = 2 * 21

# You don't need to change the following line, it just
# outputs the value of x to the console
print(x)

