Implement `script.py` so that x is 42 without using the number 42.

