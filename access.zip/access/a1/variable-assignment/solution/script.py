#!/usr/bin/env python3

x = 21 + 21
print(x)

