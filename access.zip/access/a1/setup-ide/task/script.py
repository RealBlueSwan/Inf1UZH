#!/usr/bin/env python3

# This is the string you should change
version = "Replace these words with your version output"

# You don't need to change the following line, it just
# outputs the value of version to the console
print(version)

