#!/usr/bin/env python3

# perform a ROTn encoding
def rot_n(plain_text, shift_by):
    # Make sure to return the correct result!
    return

print(rot_n("abc", 1))

