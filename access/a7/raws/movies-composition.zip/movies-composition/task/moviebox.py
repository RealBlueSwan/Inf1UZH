#!/usr/bin/env python3

# Implement this class. Stick to the naming that is introduced in the
# UML diagram. Do not change the class name or the method signatures
# or the automated grading won't work.

from task.movie import Movie


class MovieBox:
    def __init__(self, title, movies):
        pass

    def get_title(self):
        pass

    def get_actors(self):
        pass

    def get_duration(self):
        pass

    def get_movies(self):
        pass

    # also implement the required special functions
