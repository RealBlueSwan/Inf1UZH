#!/usr/bin/env python3

# Implement this class. Stick to the naming that is introduced in the
# UML diagram. Do not change the class name or the method signatures
# or the automated grading won't work.

from task.movie import Movie
from task.moviebox import MovieBox


class Library:
    def add_movie(self, movie):
        pass

    def get_movies(self):
        pass

    def get_total_duration(self):
        pass
