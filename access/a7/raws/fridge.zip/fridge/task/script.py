#!/usr/bin/env python3

class Fridge:
    pass

