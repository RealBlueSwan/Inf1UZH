#!/usr/bin/env python3

class Matrix:
    pass

    # Also, implement the special methods __eq__, __hash__, __add__, and __mul__
    # as per the task description.

    # def __eq__(self, other):
    #   etc ...

# Make sure to work on task/tests.py as well to test your implementation!

