#!/usr/bin/env python3

# You can implement this function, but you do not have to.
# The grading will only depend on your test suite.
#
# This signature is required for the automated grading to work.
# You must not rename the function or change its list of parameters.

def sorted_arrays_overlap(array_1, array_2):
	pass


# Examples:
# array_1 = [-5, -3, -1, 7, 8, 14, 19]
# array_2 = [-8, -5, -2, -1, 19]
# result = sorted_arrays_overlap(array_1, array_2)
# print(result)  # [-5, -1, 19]
#
# array_1 = [5, 8, 14, 19, 19, 19, 23, 34, 52]
# array_2 = [2, 5, 7, 8, 15, 19, 19, 25, 34, 62]
# result = sorted_arrays_overlap(array_1, array_2)
# print(result)  # [5, 8, 19, 19, 34]
