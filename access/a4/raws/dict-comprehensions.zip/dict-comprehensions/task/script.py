from math import pi
number_list = [1, 2, 3, 4, 5, 6, 7, 8, 9]

def square_root_dict(numbers: [int]):
    return {x: x**0.5 for x in numbers}


def even_odd_dict(numbers: [int]):
    pass


def area_dict(numbers: [int]):
    pass


def smaller_larger_dict(numbers: [int]):
    pass


print(square_root_dict(number_list))
