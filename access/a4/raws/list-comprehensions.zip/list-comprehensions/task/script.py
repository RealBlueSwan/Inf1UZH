#!/usr/bin/python3

def square_numbers(numbers):
    '''this one just serves as an example'''
    return [ number ** 2 for number in numbers ]

def even_numbers(numbers):
    pass

def all_even(numbers):
    pass

def only_integers(numbers):
    pass

def only_positive(numbers):
    pass

def from_1_to_1000_containing_a(a):
    pass

def multiple_of_a_and_greater_than_b(numbers, a, b):
    pass


