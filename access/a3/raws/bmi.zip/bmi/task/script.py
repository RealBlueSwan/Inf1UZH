#!/usr/bin/env python3

# Height in M
height = 10
# Weight in KG
weight = 10


# Determine the BMI. Change the function
# below to calculate the BMI return which category the result is in.
# Your implementation should work with any specific value.
# You must use the variables defined above.


def get_bmi_category():
    # You need to change the following part of the function
    # to determine the BMI and return the correct category.
    bmi = "..."
    # Return the BMI values and the correct category after you have calculated the BMI.


# The following line calls the function and prints the return
# value to the Console. This way you can check what it does.
print(get_bmi_category())
