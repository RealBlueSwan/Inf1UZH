#!/usr/bin/python3

words = ["apple", "mountain", "river", "asteroid", "armadillo", "guitar",
         "sapphire", "keyboard", "planet", "mango", "mirror", "jazz", "robot",
         "lighthouse", "pineapple", "wizard", "cloud", "penguin", "spaghetti"]

def words_with_length(length):
    '''this one just serves as an example'''
    return [word for word in words if len(word) == length]

def words_containing_string(s):
    pass

def words_starting_with_character(c):
    pass

def words_with_matching_ends():
    pass

def words_with_unique_characters():
    pass

def count_unique_characters():
    pass

def dictionary():
    pass

