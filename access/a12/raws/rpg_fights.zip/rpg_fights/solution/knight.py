#!/usr/bin/env python3

from task.character import Character

class Knight(Character):

    def _get_caused_dmg(self, other):
        dmg = super()._get_caused_dmg(other)
        return round(0.8*dmg)

    def _take_physical_damage(self, amount):
        amount = round(0.75*amount)
        super()._take_physical_damage(amount)
