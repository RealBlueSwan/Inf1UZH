#!/usr/bin/env python3

from task.character import Character

# As Rogue follows the rules defined before in Character.
class Rogue(Character):
    pass
