#!/usr/bin/env python3

from task.character import Character

class Mage(Character):

    def attack(self, other):
        assert isinstance(other, Character)
        assert self is not other

        if not self.is_alive():
            raise Warning("Character is dead!")

        other._take_magical_damage(self._get_caused_dmg(other))


    def _get_caused_dmg(self, other):
        dmg = super()._get_caused_dmg(other)
        return round(1.25 * dmg)

    def _take_physical_damage(self, amount):
        super()._take_physical_damage(round(1.5 * amount))

    def _take_magical_damage(self, amount):
        super()._take_magical_damage(round(1.5 * amount))
