#!/usr/bin/env python3

class Inventory:
    def __init__(self):
        pass

    def collect(self, item):
        pass

    def get_inv_weight(self):
        pass
    def get_balance(self):
        pass
    def get_inv_value(self):
        pass
    def drop(self, item):
        pass

    def sell(self, item):
        pass

    def buy(self, item):
        pass

#implement this function to check if a given object fits the described type for an item (3-tuple of string, int, int)
#raise a Warning if it doesn't
    def __proper_item(self, item):
        pass

    def __iter__(self):
        return iter(sorted(self.__content, key=lambda item: item[1], reverse=True))

    def __len__(self):
        pass
