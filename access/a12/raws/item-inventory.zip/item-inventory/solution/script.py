#!/usr/bin/env python3

class Inventory:
    def __init__(self, player_name="DEFAULT", balance=0, max_weight=0):
        self.__player_name = player_name
        self.__balance = balance
        self.__weight_cap = max_weight
        self.__content = []

    def collect(self, item):
        self.__proper_item(item)
        if self.__weight_cap - self.get_inv_weight() > item[2]:
            self.__content.append(item)
        else:
            raise Warning

    def get_inv_weight(self):
        return sum([item[2] for item in self.__iter__()])

    def get_balance(self):
        return self.__balance

    def get_player_name(self):
        return self.__player_name

    def get_inv_value(self):
        return sum([item[1] for item in self.__iter__()])

    def drop(self, item):
        self.__proper_item(item)
        if item in self.__content:
            self.__content.remove(item)
            return item
        else:
            raise Warning

    def sell(self, item):
        self.__proper_item(item)
        if item in self.__content:
            self.__content.remove(item)
            self.__balance += item[1]
            return item
        else:
            raise Warning

    def buy(self, item):
        self.__proper_item(item)
        if item[1] <= self.__balance and self.__weight_cap - self.get_inv_weight() > item[2]:
            self.__content.append(item)
            self.__balance -= item[1]
            return item
        else:
            raise Warning

    def __proper_item(self, item):
        if (type(item) != tuple or not tuple or len(item) != 3 or type(item[0]) != str
                or type(item[1]) != int or type(item[2]) != int):
            raise Warning

    def __iter__(self):
        return iter(sorted(self.__content, key=lambda item: item[1], reverse=True))

    def __len__(self):
        return len(self.__content)
