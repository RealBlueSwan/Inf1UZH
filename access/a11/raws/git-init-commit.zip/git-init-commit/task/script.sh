#!/bin/sh

# Add your terminal commands here. Make sure to first run them
# locally on your machine to have more detailed error output.
echo "Hello World!"
