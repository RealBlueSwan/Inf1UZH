#!/usr/bin/env python3

class MagicDrawingBoard:
    def __init__(self, x, y):
        pass

# You can play around with your implementation in the body of the following 'if'.
# The contained statements will be ignored while evaluating your solution.
if __name__ == '__main__':
    db = MagicDrawingBoard(1,1)
    #db.pixel((-1,0))
