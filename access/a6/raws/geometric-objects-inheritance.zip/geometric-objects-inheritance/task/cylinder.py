from task.geometric_object import GeometricObject


class Cylinder(GeometricObject):
    def __init__(self, color, filled, radius, height):
        pass

    def area(self):
        pass

    def volume(self):
        pass
