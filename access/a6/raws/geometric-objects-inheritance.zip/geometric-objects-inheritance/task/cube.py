from task.geometric_object import GeometricObject


class Cube(GeometricObject):
    def __init__(self, color, filled, side_length):
        pass

    def area(self):
        pass

    def volume(self):
        pass
