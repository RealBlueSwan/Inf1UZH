#!/usr/bin/env python3

# The signatures of this class is required for the automated grading to work.
# You must not change its name.
# You must add the correct signatures for each missing method as outlined
# in the task instructions.
class BankAccount:
    pass
    # implement the necessary methods

# The following lines call the functionality
# This way you can check what it does.

#my_account = BankAccount("Melon Tusk", 269800000000)
#my_account.withdraw(200000000000)
#print(my_account)
#print(repr(my_account))
