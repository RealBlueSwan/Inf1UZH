#!/usr/bin/env python3

from abc import ABC, abstractmethod


class Person():

    def __init__(self, name: str, email: str):
        pass

    def get_details(self) -> str:
        pass
