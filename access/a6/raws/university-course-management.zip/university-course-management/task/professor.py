#!/usr/bin/env python3

from task.person import Person


class Professor():

    def __init__(self, name: str, email: str, employee_id: str, office: str):
        pass

    def get_details(self) -> tuple:
        pass
