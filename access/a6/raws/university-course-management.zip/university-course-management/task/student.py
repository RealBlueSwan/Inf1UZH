#!/usr/bin/env python3

from task.person import Person


class Student():

    def __init__(self, name: str, email: str, student_id: str):
        pass

    def get_details(self) -> tuple:
        pass
