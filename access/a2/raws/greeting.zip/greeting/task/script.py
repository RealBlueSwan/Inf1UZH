#!/usr/bin/env python3

def generate_greeting(name, age):
    # Modify this return statement so that the correct result is returned
    return "..."

# The following line calls the function and prints its return value. You don't
# need to change it, it's only here so you can see the result in the "Console
# Output" tab below
print(generate_greeting("Hans", 37))

