#!/usr/bin/env python3

# Change the function below to calculate the result
# with the given formula:
# `a - (b^2 / (c - d * (a + b)))`
def calculate(a, b, c, d):
    # Modify this return statement so that the correct result is returned
    return 0

# The following line calls the function and prints its return value. You don't
# need to change it, it's only here so you can see the result in the "Console
# Output" tab below
print(calculate(1, 2, 3, 4))

