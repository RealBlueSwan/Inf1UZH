#!/usr/bin/env python3

def zoo(number):
    # return a tuple containing the required values
    return
