You must install Jupyter Notebook or Jupyter Lab for your operating system:

https://github.com/jupyterlab/jupyterlab-desktop?tab=readme-ov-file#installation

Then, you can open tutorial_01/01_tutorial.ipynb using Jupyter Notebook or Jupyter Lab.
